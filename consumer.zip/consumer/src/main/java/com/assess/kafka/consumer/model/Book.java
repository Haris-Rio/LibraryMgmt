package com.assess.kafka.consumer.model;

public class Book {
	Long id;
	String title;
	String author;
}
