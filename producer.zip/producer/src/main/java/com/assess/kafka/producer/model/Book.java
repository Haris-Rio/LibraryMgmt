package com.assess.kafka.producer.model;

public class Book {
	Long id;
	String title;
	String author;
}
